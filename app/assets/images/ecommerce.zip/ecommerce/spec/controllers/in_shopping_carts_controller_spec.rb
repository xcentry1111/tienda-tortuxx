require 'rails_helper'

RSpec.describe InShoppingCartsController, type: :controller do

end
