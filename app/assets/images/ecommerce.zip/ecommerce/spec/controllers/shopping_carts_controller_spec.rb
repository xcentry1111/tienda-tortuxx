require 'rails_helper'

RSpec.describe ShoppingCartsController, type: :controller do

end
